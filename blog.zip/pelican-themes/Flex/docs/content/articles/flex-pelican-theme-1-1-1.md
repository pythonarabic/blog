Title: Flex 1.1.1
Date: 2016-02-27 08:00
Modified: 2016-02-27 08:00
Category: News
Tags: pelican, python, theme
Slug: flex-pelican-theme-update-1-1-1
Cover: images/flex-screenshot.png

Today, [Flex theme](https://github.com/alexandrevicenzi/Flex) received a small update.

Some bugs are now fixed. I think the most important fixes are:

- [Bug in CSS with placement of "Newer Posts" button](https://github.com/alexandrevicenzi/Flex/issues/21)
- [Posts preview on main page](https://github.com/alexandrevicenzi/Flex/issues/14)

Hope you enjoy this theme.
