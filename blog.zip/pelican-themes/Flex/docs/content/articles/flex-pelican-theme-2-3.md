Title: Flex 2.3.0
Date: 2020-09-19 08:00
Modified: 2020-09-19 08:00
Category: News
Tags: pelican, python, theme
Slug: flex-pelican-theme-update-2-3
Cover: images/flex-screenshot.png

[Flex theme](https://github.com/alexandrevicenzi/Flex) 2.3.0 comes with bug fixes and a few improvements.

New features include:

- Dark Theme version
- Isso comments support
- Tipue Search support
- Update translations

Fixes include:

- New social icons
- Layout fixes
- Compatibility with newer Pelican

For more details check our [Wiki](https://github.com/alexandrevicenzi/Flex/wiki).

I know, it has been a long time since the last version, but it's out now.

Hope you enjoy this version.
