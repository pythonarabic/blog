Title: My First Review مرحبا hello
Date: 2020-12-03 10:20
Category: Review
tags: python, بايثون 101
summary: مرحبا من الملخص
author: Essa Alshammari



Following is a review of my favorite mechanical keyboard.

~~~
arr = [2,4,6,3,8,10]

for index,value in enumerate(arr):
    print(f"At Index {index} The Value Is -> {value}")
~~~

# My First Review مرحبا hello

# مرحبا

# hello
# مرحبا
